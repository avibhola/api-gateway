package com.stackroute.user_registration_service.model;

public class AdminDetails {

}
