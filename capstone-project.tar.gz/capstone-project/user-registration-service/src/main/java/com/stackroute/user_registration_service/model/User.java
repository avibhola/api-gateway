package com.stackroute.user_registration_service.model;

import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Positive;
import jakarta.validation.constraints.Size;

@Entity
@Table
public class User {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long customerId;

	@NotEmpty
	private String name;

	@Email
	@NotEmpty
	@Column(unique = true)
	private String email;

	@NotEmpty
	@Size(min = 8)
	private String password;

	@Pattern(regexp = "\\d{12}")
	private String aadhaarNumber;

	@Pattern(regexp = "[A-Z]{5}\\d{4}[A-Z]{1}")
	private String panCardNumber;

	@NotEmpty
	private String address;

	@Pattern(regexp = "\\d{10}")
	private String mobileNumber;

	private String jobRole;

	@Positive
	private Integer monthlyIncome;

	private LocalDateTime registrationDate;

	public Long getCustomerId() {
		return customerId;
	}

	public void setCustomerId(Long customerId) {
		this.customerId = customerId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getAadhaarNumber() {
		return aadhaarNumber;
	}

	public void setAadhaarNumber(String aadhaarNumber) {
		this.aadhaarNumber = aadhaarNumber;
	}

	public String getPanCardNumber() {
		return panCardNumber;
	}

	public void setPanCardNumber(String panCardNumber) {
		this.panCardNumber = panCardNumber;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String getJobRole() {
		return jobRole;
	}

	public void setJobRole(String jobRole) {
		this.jobRole = jobRole;
	}

	public Integer getMonthlyIncome() {
		return monthlyIncome;
	}

	public void setMonthlyIncome(Integer monthlyIncome) {
		this.monthlyIncome = monthlyIncome;
	}

	public LocalDateTime getRegistrationDate() {
		return registrationDate;
	}

	public void setRegistrationDate(LocalDateTime registrationDate) {
		this.registrationDate = registrationDate;
	}

	public User(Long customerId, @NotEmpty String name, @Email @NotEmpty String email,
			@NotEmpty @Size(min = 8) String password, @Pattern(regexp = "\\d{12}") String aadhaarNumber,
			@Pattern(regexp = "[A-Z]{5}\\d{4}[A-Z]{1}") String panCardNumber, @NotEmpty String address,
			@Pattern(regexp = "\\d{10}") String mobileNumber, String jobRole, @Positive Integer monthlyIncome,
			LocalDateTime registrationDate) {
		super();
		this.customerId = customerId;
		this.name = name;
		this.email = email;
		this.password = password;
		this.aadhaarNumber = aadhaarNumber;
		this.panCardNumber = panCardNumber;
		this.address = address;
		this.mobileNumber = mobileNumber;
		this.jobRole = jobRole;
		this.monthlyIncome = monthlyIncome;
		this.registrationDate = registrationDate;
	}

	@Override
	public String toString() {
		return "User [customerId=" + customerId + ", name=" + name + ", email=" + email + ", password=" + password
				+ ", aadhaarNumber=" + aadhaarNumber + ", panCardNumber=" + panCardNumber + ", address=" + address
				+ ", mobileNumber=" + mobileNumber + ", jobRole=" + jobRole + ", monthlyIncome=" + monthlyIncome
				+ ", registrationDate=" + registrationDate + "]";
	}

	public User() {
		super();
	}

  
}
