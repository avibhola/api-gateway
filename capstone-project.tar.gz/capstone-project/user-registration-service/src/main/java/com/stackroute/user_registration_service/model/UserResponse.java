package com.stackroute.user_registration_service.model;

public class UserResponse {

	private String jobRole;
	private double monthlyIncome;

	public UserResponse(String jobRole, double monthlyIncome) {
		this.jobRole = jobRole;
		this.monthlyIncome = monthlyIncome;
	}

	public String getRole() {
		return jobRole;
	}

	public double getMonthlyIncome() {
		return monthlyIncome;
	}
}
