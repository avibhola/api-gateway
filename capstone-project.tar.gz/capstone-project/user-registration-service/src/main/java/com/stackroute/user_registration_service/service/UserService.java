package com.stackroute.user_registration_service.service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.stackroute.user_registration_service.model.User;
import com.stackroute.user_registration_service.repository.UserRepository;

import jakarta.validation.Valid;

@Service
public class UserService {
	@Autowired
	private UserRepository userRepository;

	public User registerUser(@Valid User user) {
		user.setRegistrationDate(LocalDateTime.now());
		return userRepository.save(user);
	}

	public Optional<User> getUserById(Long id) {
		return userRepository.findById(id);
	}

	public List<User> getAllUsers() {
		return userRepository.findAll();
	}

	public List<User> filterUsers(String jobRole, Integer minSalary, Integer maxSalary) {
		// Implementing filter logic
		List<User> users = userRepository.findAll();
		return users.stream()
				.filter(user -> (jobRole == null || user.getJobRole().equalsIgnoreCase(jobRole))
						&& (minSalary == null || user.getMonthlyIncome() >= minSalary)
						&& (maxSalary == null || user.getMonthlyIncome() <= maxSalary))
				.toList();
	}
}
