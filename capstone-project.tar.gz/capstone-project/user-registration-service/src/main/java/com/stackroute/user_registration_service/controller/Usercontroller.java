package com.stackroute.user_registration_service.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.stackroute.user_registration_service.model.User;
import com.stackroute.user_registration_service.service.UserService;

@RestController
@RequestMapping("/api")
public class Usercontroller {

	@Autowired
	private UserService userService;

	@PostMapping("/register")
	public ResponseEntity<User> register(@Validated @RequestBody User user) {
		User registeredUser = userService.registerUser(user);
		return new ResponseEntity<>(registeredUser, HttpStatus.CREATED);
	}

	@GetMapping("/getUserDetails/{customerId}")
	public ResponseEntity<Map<String, Object>> getUserDetails(@PathVariable Long customerId) {
		System.out.println("jahadfasd" + customerId);
		Optional<User> userOptional = userService.getUserById(customerId);
		if (userOptional.isPresent()) {
			Map<String, Object> response = new HashMap<>();
			response.put("jobRole", userOptional.get().getJobRole()); // Change to "jobRole"
			response.put("monthlyIncome", userOptional.get().getMonthlyIncome());
			return ResponseEntity.ok().body(response);
		} else {
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
	}

	@GetMapping("/admin/getAllUsers")
	public ResponseEntity<List<User>> getAllUsers() {
		List<User> users = userService.getAllUsers();
		return ResponseEntity.ok(users);
	}

	@GetMapping("/admin/filterUsers")
	public ResponseEntity<List<User>> filterUsers(@RequestParam(required = false) String jobRole,
			@RequestParam(required = false) Integer minSalary, @RequestParam(required = false) Integer maxSalary) {
		List<User> filteredUsers = userService.filterUsers(jobRole, minSalary, maxSalary);
		return ResponseEntity.ok(filteredUsers);
	}
}
