package com.stackroute.payment_service.entity;

public class PaymentPayload {
	private Double amount;

	public Double getAmount() {
		return amount;
	}

	public void setAmount(Double amount) {
		this.amount = amount;
	}

	public PaymentPayload(Double amount) {
		super();
		this.amount = amount;
	}
	
	public PaymentPayload() {
		
		
	}
	
	

}
