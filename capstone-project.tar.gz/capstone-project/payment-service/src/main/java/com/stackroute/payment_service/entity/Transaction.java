package com.stackroute.payment_service.entity;

import java.util.Date;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Transaction {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long transactionId;
    private String customerId;
    private String merchantId;
    private double amount; // Must be a positive number
    private Date date;
    private String transactionStatus; // "Success" or "Failed"

    public Transaction(Long transactionId, String customerId, String merchantId, double amount, Date date, String transactionStatus) {
        this.transactionId = transactionId;
        this.customerId = customerId;
        this.merchantId = merchantId;
        setAmount(amount);
        this.date = date;
        this.transactionStatus = transactionStatus;
    }

    public Transaction() {
		super();
	}

	public Long getTransactionId() {
        return transactionId;
    }

    public String getCustomerId() {
        return customerId;
    }

    public String getMerchantId() {
        return merchantId;
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        if (amount <= 0) {
            throw new IllegalArgumentException("Amount must be a positive number.");
        }
        this.amount = amount;
    }

    public Date getDate() {
        return date;
    }

    public String getTransactionStatus() {
        return transactionStatus;
    }

    public void setTransactionStatus(String transactionStatus) {
        this.transactionStatus = transactionStatus;
    }

	@Override
	public String toString() {
		return "Transaction [transactionId=" + transactionId + ", customerId=" + customerId + ", merchantId="
				+ merchantId + ", amount=" + amount + ", date=" + date + ", transactionStatus=" + transactionStatus
				+ "]";
	}
    
}
