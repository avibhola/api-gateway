package com.stackroute.payment_service.controller;
import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.stackroute.payment_service.entity.PaymentPayload;
import com.stackroute.payment_service.entity.PaymentRequest;
import com.stackroute.payment_service.exception.PaymentFailureException;
import com.stackroute.payment_service.service.PaymentService;

@RestController
@RequestMapping("/api/payments")
public class PaymentController {


	    @Autowired
	    private PaymentService paymentService;

	    @PostMapping("/makePayment/{customerId}")
	    public ResponseEntity<String> makePayment(@PathVariable Long customerId, @RequestBody PaymentPayload payload) {
	        String response = paymentService.makePayment(customerId, payload);
	        
	        return ResponseEntity.ok(response);
	    }

	    @PostMapping("/payToMerchant")
	    public ResponseEntity<String> payToMerchant(@RequestBody PaymentRequest request) {
	        String response = paymentService.payToMerchant(request);
	        return ResponseEntity.ok(response);
	    }
	}
