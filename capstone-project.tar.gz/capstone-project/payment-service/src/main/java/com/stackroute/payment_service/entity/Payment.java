package com.stackroute.payment_service.entity;

import java.util.Date;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Payment {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long paymentId;
    private double amount; // Must be a positive number
    private Date date;
    
    private String paymentStatus; // "Completed" or "Pending"

    public Payment(Long paymentId, double amount, Date date, String paymentStatus) {
        this.paymentId = paymentId;
        setAmount(amount);
        this.date = date;
        this.paymentStatus = paymentStatus;
    }

    public Long getPaymentId() {
        return paymentId;
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        if (amount <= 0) {
            throw new IllegalArgumentException("Amount must be a positive number.");
        }
        this.amount = amount;
    }

    public Date getDate() {
        return date;
    }

    public String getPaymentStatus() {
        return paymentStatus;
    }

    public void setPaymentStatus(String paymentStatus) {
        this.paymentStatus = paymentStatus;
    }

	public Payment() {
		super();
	}

	@Override
	public String toString() {
		return "Payment [paymentId=" + paymentId + ", amount=" + amount + ", date=" + date + ", paymentStatus="
				+ paymentStatus + "]";
	}
    
}
