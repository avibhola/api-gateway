package com.stackroute.payment_service.service;
import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.stackroute.payment_service.entity.PaymentPayload;
import com.stackroute.payment_service.entity.PaymentRequest;
import com.stackroute.payment_service.exception.PaymentFailureException;
@Service
public class PaymentService {

    private  static Map<Long, Double> customerBalances = new HashMap<>(); // Simulating customer balances
    
    
    private CreditCardService creditCardService = new CreditCardService();

    // Constructor to initialize some customer balances for testing
    public PaymentService() {
    	customerBalances.put(123l, 12000.0);
    	customerBalances.put(124l, 16000.0);
    }

    
    public String makePayment(Long customerId, PaymentPayload payload) {
    	Double amount=payload.getAmount();
    	
        // Check if the customer exists and retrieve their balance (simulated here)
        double customerTotalBalance = customerBalances.getOrDefault(customerId, 10000.0);

        // Check if the amount is valid and sufficient
        if (amount <= 0) {
            throw new PaymentFailureException("Amount must be a positive number.");
        }
        if (customerTotalBalance < amount) {
            throw new PaymentFailureException("Insufficient funds");
        }

        // Deduct the amount from the customer's balance
        customerBalances.put(customerId, customerTotalBalance - amount);

        // Simulate updating the credit card balance (this would be a call to an external service)
        //creditCardService.updateBalance(customerId, amount);

        // Return confirmation message
        return "Payment of " + amount + " made successfully. New balance: " + (customerTotalBalance - amount);
    }

    public String payToMerchant(PaymentRequest request) {
        // Validate credit card details
        if (!creditCardService.validateCard(request.getCardNumber(),request.getCvv(),request.getExpirationDate())) {
            throw new PaymentFailureException("Invalid card details");
        }

        // Process payment
        return processTransaction(request.getCustomerId(), request.getMerchantId(), request.getAmount());
    }

    private String processTransaction(Long customerId, String merchantId, double amount) {
        // Simulating payment processing
    	 double customerTotalBalance  = customerBalances.getOrDefault(customerId, 12400.0);
        if (customerTotalBalance < amount || customerTotalBalance<=0) {
            throw new PaymentFailureException("Insufficient funds");
        }

        customerBalances.put(customerId, customerTotalBalance - amount);
        return "Transaction successful. Amount: " + amount + " paid to merchant " + merchantId + "Balance:"+customerTotalBalance;
    }
}
