package com.stackroute.credit_card_service.services;

import java.util.List;

import com.stackroute.credit_card_service.entity.Bill;
import com.stackroute.credit_card_service.entity.Card;

public interface CardService {
	public Card issueCard(Long customerId);

	public Card getCardByCustomerId(Long customerId);

	public Bill generateBill(Long customerId);
	public List<Bill> getBillsByCustomerId(Long customerId);

}
