package com.stackroute.credit_card_service.entity;

public class CardResponse {
    private String cardNumber;
    private double creditLimit;
    private String expirationDate;
    private String cvv;

    public CardResponse(String cardNumber, double creditLimit, String expirationDate, String cvv) {
        this.cardNumber = cardNumber;
        this.creditLimit = creditLimit;
        this.expirationDate = expirationDate;
        this.cvv = cvv;
    }

	public String getCardNumber() {
		return cardNumber;
	}

	public void setCardNumber(String cardNumber) {
		this.cardNumber = cardNumber;
	}

	public double getCreditLimit() {
		return creditLimit;
	}

	public void setCreditLimit(double creditLimit) {
		this.creditLimit = creditLimit;
	}

	public String getExpirationDate() {
		return expirationDate;
	}

	public void setExpirationDate(String expirationDate) {
		this.expirationDate = expirationDate;
	}

	public String getCvv() {
		return cvv;
	}

	public void setCvv(String cvv) {
		this.cvv = cvv;
	}

    // Getters can be added here
}
