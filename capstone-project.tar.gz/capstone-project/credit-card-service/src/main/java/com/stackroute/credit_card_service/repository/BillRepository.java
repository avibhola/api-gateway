package com.stackroute.credit_card_service.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.stackroute.credit_card_service.entity.Bill;

public interface BillRepository extends JpaRepository<Bill, Long> {

}
