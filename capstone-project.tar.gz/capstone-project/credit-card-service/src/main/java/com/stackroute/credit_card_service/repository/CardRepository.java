package com.stackroute.credit_card_service.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.stackroute.credit_card_service.entity.Card;

public interface CardRepository extends JpaRepository<Card, String>{
	Card findByCustomerId(Long customerId);

}
