package com.stackroute.credit_card_service.entity;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import com.fasterxml.jackson.databind.annotation.JsonPOJOBuilder;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Bill {
    public Bill() {
		
	}
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long billId;
	private Long customerId;
    private String details;
    private double amount;
    private LocalDate billingMonth; // Use LocalDate for more flexibility

    // Constructor
    public Bill(Long customerId, String details, double amount, LocalDate billingMonth) {
        this.customerId = customerId;
        this.details = details;
        this.amount = amount;
        this.billingMonth = billingMonth;
    }

    // Getters
    public Long getCustomerId() {
        return customerId;
    }

    public String getDetails() {
        return details;
    }

    public double getAmount() {
        return amount;
    }

    public LocalDate getBillingMonth() {
        return billingMonth;
    }

    // Method to format billing month as a string in MM/YYYY format
    public String getFormattedBillingMonth() {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM/yyyy");
        return billingMonth.format(formatter);
    }

    // Setters (optional, depending on your use case)
    public void setCustomerId(Long customerId) {
        this.customerId = customerId;
    }

    public void setDetails(String details) {
        this.details = details;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public void setBillingMonth(LocalDate billingMonth) {
        this.billingMonth = billingMonth;
    }
}
