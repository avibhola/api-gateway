package com.stackroute.credit_card_service.entity;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.Base64;
import jakarta.persistence.*;

@Entity
public class Card {
	
	@Id
    private String cardId;
    private Long customerId;
    private String cardNumber; // Encrypted card number
    private String cvv; // Encrypted CVV
    private String expirationDate; // MM/YY format
    private double creditLimit;
    private double outstandingBalance;
    private boolean active;

    public String getCardId() {
		return cardId;
	}

	public void setCardId(String cardId) {
		this.cardId = cardId;
	}

	public Long getCustomerId() {
		return customerId;
	}

	public void setCustomerId(Long customerId) {
		this.customerId = customerId;
	}

	public String getCardNumber() {
		return cardNumber;
	}

	public void setCardNumber(String cardNumber) {
		this.cardNumber = cardNumber;
	}

	public String getCvv() {
		return cvv;
	}

	public void setCvv(String cvv) {
		this.cvv = cvv;
	}

	public String getExpirationDate() {
		return expirationDate;
	}

	public void setExpirationDate(String expirationDate) {
		this.expirationDate = expirationDate;
	}

	public double getCreditLimit() {
		return creditLimit;
	}

	public void setCreditLimit(double creditLimit) {
		this.creditLimit = creditLimit;
	}

	public double getOutstandingBalance() {
		return outstandingBalance;
	}

	public void setOutstandingBalance(double outstandingBalance) {
		this.outstandingBalance = outstandingBalance;
	}

	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	public Card() {
		super();
	}

	// Constructor to create a Card
    public Card(String cardId, Long customerId, String cardNumber, String cvv, 
                String expirationDate, double creditLimit) throws IllegalArgumentException {
        this.cardId = cardId;
        this.customerId = customerId;
        this.cardNumber = encryptCardNumber(cardNumber);
        this.cvv = encryptCVV(cvv);
        this.expirationDate = validateExpirationDate(expirationDate);
        this.creditLimit = creditLimit;
        this.outstandingBalance = 0.0; // Initial balance is zero
        this.active = true; // Card is active when created
    }

    // Method to encrypt card number (placeholder for actual encryption logic)
    private String encryptCardNumber(String cardNumber) {
        validateCardNumber(cardNumber);
        // Implement encryption logic here
        return Base64.getEncoder().encodeToString(cardNumber.getBytes()); // Placeholder
    }

    // Method to encrypt CVV (placeholder for actual encryption logic)
    private String encryptCVV(String cvv) {
        validateCVV(cvv);
        // Implement encryption logic here
        return Base64.getEncoder().encodeToString(cvv.getBytes()); // Placeholder
    }

    // Validate card number (16 digits)
    private void validateCardNumber(String cardNumber) {
        if (!cardNumber.matches("^\\d{16}$")) {
            throw new IllegalArgumentException("Card number must be a 16-digit number.");
        }
    }

    // Validate CVV (3 digits)
    private void validateCVV(String cvv) {
        if (!cvv.matches("^\\d{3}$")) {
            throw new IllegalArgumentException("CVV must be a 3-digit number.");
        }
    }

    private String validateExpirationDate(String expirationDate) {
        // Regular expression to validate MM/YY format
        String regex = "^(0[1-9]|1[0-2])/[0-9]{2}$";
        if (!expirationDate.matches(regex)) {
            throw new IllegalArgumentException("Expiration date must be in MM/YY format.");
        }

        try {
            // Split the input into month and year
            String[] parts = expirationDate.split("/");
            int month = Integer.parseInt(parts[0]);
            int year = Integer.parseInt(parts[1]) + 2000; // Adjusting for the year to make it a full year (YY to YYYY)

            // Create a LocalDate object for the first day of the month
            LocalDate expDate = LocalDate.of(year, month, 1);

            // Check if the expiration date is in the future
            if (expDate.isBefore(LocalDate.now())) {
                throw new IllegalArgumentException("Expiration date must be in the future.");
            }

            return expirationDate;
        } catch (Exception e) {
            throw new IllegalArgumentException("Error parsing the expiration date: " + e.getMessage());
        }
    }

    // Eligibility check for issuing the card
    public static boolean checkEligibility(String jobRole, double monthlyIncome) {
        // Simple eligibility rules
        if ("Salaried".equalsIgnoreCase(jobRole) && monthlyIncome >= 25000) {
            return true;
        } else if ("Freelancer".equalsIgnoreCase(jobRole) && monthlyIncome >= 50000) {
            return true;
        } else if ("Student".equalsIgnoreCase(jobRole) && monthlyIncome < 10000) {
            return true; // Assuming students can have a card with low limit
        }
        return false;
    }

    // Getters and setters (optional) can be added as needed

   
}
