package com.stackroute.credit_card_service.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.stackroute.credit_card_service.entity.Bill;
import com.stackroute.credit_card_service.entity.Card;
import com.stackroute.credit_card_service.entity.CardRequest;
import com.stackroute.credit_card_service.entity.CardResponse;
import com.stackroute.credit_card_service.services.CardService;

@RestController
@RequestMapping("/api/card")
public class CardController {
	@Autowired
	private CardService cardService;

	@PostMapping("/issue")
	public ResponseEntity<CardResponse> issueCard(@RequestBody CardRequest cardRequest) {
		Long customerId = cardRequest.getCustomerId();
		Card issuedCard = cardService.issueCard(customerId);

		CardResponse response = new CardResponse(issuedCard.getCardNumber(), issuedCard.getCreditLimit(),
				issuedCard.getExpirationDate(), issuedCard.getCvv());
		return ResponseEntity.ok(response);
	}

	@GetMapping("/{customerId}")
	public ResponseEntity<?> getCard(@PathVariable Long customerId) {
		Card card = cardService.getCardByCustomerId(customerId);
		if (card == null) {
			return ResponseEntity.status(404).body("Card not found for customer ID: " + customerId);
		}
		if (!card.isActive()) {
			return ResponseEntity.ok("Card is inactive.");
		}
		return ResponseEntity.ok(card);
	}

	// Endpoint to generate a new monthly bill for a customer
	@PostMapping("/generateBill/{customerId}")
	public ResponseEntity<Bill> generateBill(@PathVariable Long customerId) {
		Bill newBill = cardService.generateBill(customerId);
		return ResponseEntity.ok(newBill);
	}

	    // Endpoint to retrieve current or past bills for a customer
	    @GetMapping("/getBill/{customerId}")
	    public ResponseEntity<List<Bill>> getBill(@PathVariable Long customerId) {
	        List<Bill> bills = cardService.getBillsByCustomerId(customerId);
	        if (bills.isEmpty()) {
	            return new ResponseEntity<>(null, HttpStatus.NOT_FOUND);
	        }
	        return ResponseEntity.ok(bills);
	    }

}
