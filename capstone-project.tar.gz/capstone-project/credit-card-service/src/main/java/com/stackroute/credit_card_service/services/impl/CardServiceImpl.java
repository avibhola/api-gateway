package com.stackroute.credit_card_service.services.impl;

import java.time.LocalDate;
import java.util.Calendar;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import com.stackroute.credit_card_service.entity.Bill;
import com.stackroute.credit_card_service.entity.Card;
import com.stackroute.credit_card_service.repository.BillRepository;
import com.stackroute.credit_card_service.repository.CardRepository;
import com.stackroute.credit_card_service.services.CardService;

@Service
public class CardServiceImpl implements CardService {
	@Autowired
	WebClient.Builder webClientBuilder;
	@Autowired
	private CardRepository cardRepository;
	@Autowired
	private BillRepository billRepository;

	@Override
	public Card issueCard(Long customerId) {

		Map<String, Object> jobDetailsMap = getJobDetailsOfCustomer(customerId);
		String jobRole = (String) jobDetailsMap.get("jobRole"); // Placeholder; retrieve from User Service
		Integer monthlyIncome = (Integer) jobDetailsMap.get("monthlyIncome"); // Placeholder; retrieve from User Service
		// if (Card.checkEligibility(jobRole, monthlyIncome)) {
		// Create a new card with predefined credit limit logic
		double creditLimit = determineCreditLimit(jobRole, monthlyIncome);
		// Generate a unique card number and CVV dynamically (example placeholders)
	    String cardNumber = generateCardNumber(); // Example method to generate a card number
	    String cvv = generateCVV(); // Example method to generate CVV
	    String expirationDate = generateExpirationDate(); // Example method to generate an expiration date


		Card newCard = new Card("CARD001", // Generate unique card ID
				customerId, cardNumber, // Use a new card number
				cvv, // Use a generated CVV
				expirationDate, // Set an expiration date
				creditLimit);
		cardRepository.save(newCard);
		return newCard;
		// } else {
		// throw new IllegalArgumentException("Customer is not eligible for a credit
		// card.");
		// }

	}
	
	private String generateCardNumber() {
	    // Step 1: Generate the first 15 digits randomly
	    StringBuilder cardNumber = new StringBuilder();
	    Random random = new Random();

	    // Generate 15 random digits (to leave room for the check digit)
	    for (int i = 0; i < 15; i++) {
	        cardNumber.append(random.nextInt(10));  // Append a random digit between 0 and 9
	    }

	    // Step 2: Calculate the check digit (16th digit) using Luhn algorithm
	    int checkDigit = calculateLuhnCheckDigit(cardNumber.toString());
	    cardNumber.append(checkDigit);  // Append the check digit to make the number valid

	    return cardNumber.toString();  // Return the complete 16-digit card number
	}

	// Luhn Algorithm to calculate check digit
	private int calculateLuhnCheckDigit(String cardNumber) {
	    int sum = 0;
	    boolean shouldDouble = false;

	    // Loop over the digits from right to left
	    for (int i = cardNumber.length() - 1; i >= 0; i--) {
	        int digit = Character.getNumericValue(cardNumber.charAt(i));

	        if (shouldDouble) {
	            digit *= 2;
	            if (digit > 9) {
	                digit -= 9;  // Subtract 9 if the result is greater than 9 (equivalent to adding the digits of the result)
	            }
	        }

	        sum += digit;
	        shouldDouble = !shouldDouble;  // Toggle the flag
	    }

	    // The check digit is the number that makes the sum a multiple of 10
	    int checkDigit = (10 - (sum % 10)) % 10;
	    return checkDigit;
	}
	// Method to generate a CVV
	private String generateCVV() {
	    Random rand = new Random();
	    int cvv = rand.nextInt(900) + 100; // Generates a random 3-digit CVV
	    return String.valueOf(cvv);
	}

	private String generateExpirationDate() {
	    Calendar calendar = Calendar.getInstance();
	    calendar.add(Calendar.YEAR, 2);  // Add 2 years to the current date
	    int month = calendar.get(Calendar.MONTH) + 1;  // Get month (0-indexed, so add 1)
	    int year = calendar.get(Calendar.YEAR) % 100;  // Get the last two digits of the year (e.g., 2024 -> 24)
	    return String.format("%02d/%02d", month, year);  // Format as MM/YY
	}

	private Map<String, Object> getJobDetailsOfCustomer(Long customerId) {
		return webClientBuilder.build().get().uri("http://localhost:8082/api/getUserDetails/" + customerId).retrieve()
				.bodyToMono(Map.class).block();
	}

	private double determineCreditLimit(String jobRole, double monthlyIncome) {
		// Define rules to assign credit limit

		System.out.println("JobROle is : " + jobRole + " monthlyIncome: " + monthlyIncome);
		if ("Salaried".equalsIgnoreCase(jobRole)) {
			return monthlyIncome * 2; // Example: 2x monthly income
		} else if ("Freelancer".equalsIgnoreCase(jobRole)) {
			return monthlyIncome * 1.5; // Example: 1.5x monthly income
		} else {
			return 10000; // Default limit for students
		}
	}

	@Override
	public Card getCardByCustomerId(Long customerId) {
		// TODO Auto-generated method stub
		if (customerId != null)
			return cardRepository.findByCustomerId(customerId);
		return null;
	}

	@Override
	public Bill generateBill(Long customerId) {
		double amount = 1000.00; // Example amount for the bill
		LocalDate billingMonth = LocalDate.now().minusMonths(1); // Set billing for the previous month

		// Create a new Bill instance
		Bill bill = new Bill();
		bill.setAmount(amount);
		bill.setBillingMonth(billingMonth);
		bill.setCustomerId(customerId);
		bill.setDetails("This bill is of month " + billingMonth.toString());
		// Save the bill to the data store (e.g., a list)
		billRepository.save(bill);

		return bill;
	}

	@Override
	public List<Bill> getBillsByCustomerId(Long customerId) {
		List<Bill> bills = billRepository.findAll();
		return bills.stream().filter(bill -> bill.getCustomerId().equals(customerId)) // Use equals for object
																						// comparison
				.collect(Collectors.toList());
		// TODO Auto-generated method stub
		// return bills;

	}

}
