package com.stackroute.credit_card_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.cloud.openfeign.EnableFeignClients;

@SpringBootTest
@EnableFeignClients
class CreditCardServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
